package org.ash.shining.glass.stage.teto.ran;

import org.ash.shining.glass.Entity;
import org.ash.shining.glass.stage.TetoRan;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.FloatMath;

public final class TetranGun extends Entity {

	float Radian;

	final Bitmap[] gun_graphics_list;
	public final float arm_diameter, arm_thickness;
	public boolean deletion_flag;

	TetranLeg my_mother;
	
	PointF offset;
	
	public TetranGun(TetoRan mystage, TetranLeg mother) {
		gun_graphics_list = mystage.tetran_gun_graphics_list;
		arm_diameter = gun_graphics_list[0].getHeight();
		arm_thickness = gun_graphics_list[0].getWidth();
		offset = new PointF(0, 0);
		
		Radian = 0;
		
		deletion_flag = false;
		my_mother = mother;
	}

	private int StateNumber()
	{
		double drad = Radian;
		double two_pi = 2 * Math.PI;
		while (drad < 0)
			drad += two_pi;
		while (drad >= two_pi)
			drad -= two_pi;
		Radian = (float) drad;
		int i;
		for (i = 1; i < 16; i++)
			if (Radian >= (2 * i - 1) * Math.PI / 16 && Radian < (2 * i + 1) * Math.PI / 16)
				return i;
		return 0;
	}
	private float ImageCenterX()
	{
		return gun_graphics_list[StateNumber()].getWidth() / 2.0f;
	}
	private float ImageCenterY()
	{
		return gun_graphics_list[StateNumber()].getHeight() / 2.0f;
	}
	@Override
	public int GetWidth() {
		return gun_graphics_list[StateNumber()].getWidth();
	}
	@Override
	public int GetHeight() {
		return gun_graphics_list[StateNumber()].getHeight();
	}
	@Override
	public Point GetCenter() {
		return new Point (Math.round(ImageCenterX() - arm_diameter * FloatMath.sin(Radian) / 2), Math.round(ImageCenterY() + arm_diameter * FloatMath.cos(Radian) / 2));
	}
	@Override
	public Rect GetHitbox() {
		int i = StateNumber();
		int t = (int)arm_thickness;
		int w, h;
		switch (i)
		{
		case 0:
		case 1:
		case 2:
		case 3:
			h = gun_graphics_list[i].getHeight();
			return new Rect(0, h - t, t, h);
		case 4:
		case 5:
		case 6:
		case 7:
			return new Rect(0, 0, t, t);
		case 8:
		case 9:
		case 10:
		case 11:
			w = gun_graphics_list[i].getWidth();
			return new Rect(w - t, 0, w, t);
		default:
			w = gun_graphics_list[i].getWidth();
			h = gun_graphics_list[i].getHeight();
			return new Rect(w - t, h - t, w, h);
		}
	}
	@Override
	public Rect GetAttackbox() {
		int i = StateNumber();
		return new Rect(0, 0, gun_graphics_list[i].getWidth(), gun_graphics_list[i].getHeight());
	}

	@Override
	public void SetWidth(int _w) {
		throw new IllegalStateException ();
	}
	@Override
	public void SetHeight(int _h) {
		throw new IllegalStateException();
	}
	@Override
	public void SetCenter(Point _c) {
		throw new IllegalStateException();
	}

	@Override
	public void SetHitbox(Rect _r) {
		throw new IllegalStateException();
	}
	@Override
	public void SetAttackbox(Rect _r) {
		throw new IllegalStateException();
	}

	@Override
	public float GetX() {
		return my_mother.GetAttachPoint().x + offset.x;
	}

	@Override
	public float GetY() {
		return my_mother.GetAttachPoint().y + offset.y;
	}

	@Override
	public PointF GetPosition() {
		return new PointF(GetX(), GetY());
	}

	@Override
	public boolean IsMarkedForDeletion() {
		return deletion_flag;
	}

	public void SetDegree(float d)
	{
		Radian = (float)(d * Math.PI / 180);
	}
	public float GetDegree()
	{
		return (float)(Radian * 180 / Math.PI);
	}
	
	public PointF GetShotPoint()
	{
		return new PointF(GetX() + arm_diameter * FloatMath.sin(Radian), GetY() - arm_diameter * FloatMath.cos(Radian));
	}
	
	public void onDraw(Canvas c)
	{
		Point center = this.GetCenter();
		int i = StateNumber();
		c.drawBitmap(gun_graphics_list[i], GetX() - center.x, GetY() - center.y, null);
	}
}
