package org.ash.shining.glass.stage.teto.ran;

public enum CruiserTetranState {
	EMERGENCE,
	BACK_BULLET_CW,
	ONEBYONE_LASER_CW,
	BURST_LASER_CW,
	BACK_BULLET_CCW,
	ONEBYONE_LASER_CCW,
	BURST_LASER_CCW,
	TETRAN_SWORD,
	DESTRUCTION, STAGE_INIT
}
