package org.ash.shining.glass.stage.teto.ran;

import org.ash.shining.glass.Entity;
import org.ash.shining.glass.GameView;
import org.ash.shining.glass.stage.TetoRan;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.FloatMath;

public final class TetranLeg extends Entity {
	
	float Radian;

	final Bitmap[] leg_graphics_list;
	public final float arm_diameter, arm_thickness;
	public boolean deletion_flag;
	
	boolean move_at_entity;
	TetranLeg my_mother;
	
	PointF offset;
	
	private Rect[] hitbox_precache;
	private Rect[] attackbox_precache;
	private boolean[] hitbox_precache_avail;
	private boolean[] attackbox_precache_avail;
	
	private float pi, two_pi, half_pi, pi_over_32, pi_over_16;
	
	public TetranLeg (TetoRan mystage)
	{
		leg_graphics_list = mystage.tetran_leg_graphics_list;
		arm_diameter = mystage.tetran_arm_size;
		arm_thickness = leg_graphics_list[0].getWidth();
		offset = new PointF(0, 0);
		
		Radian = 0;
		
		move_at_entity = false;
		deletion_flag = false;
		
		hitbox_precache = new Rect[32];
		attackbox_precache = new Rect[32];
		hitbox_precache_avail = new boolean[32];
		attackbox_precache_avail = new boolean[32];
		for (int i = 0; i < 32; i++)
		{
			hitbox_precache_avail[i] = false;
			attackbox_precache_avail[i] = false;
		}
		pi = (float) Math.PI;
		two_pi = (float) Math.PI * 2;
		half_pi = (float) Math.PI / 2;
		pi_over_32 = (float) Math.PI / 32;
		pi_over_16 = (float) Math.PI / 16;
	}
	
	public TetranLeg(TetoRan mystage, TetranLeg mother) {
		this (mystage);
		
		move_at_entity = true;
		my_mother = mother;
	}
	
	public TetranLeg (TetoRan mystage, TetranLeg mother, float offsetx, float offsety)
	{
		this (mystage, mother);
		
		offset = new PointF(offsetx, offsety);
	}
	
	private int StateNumber()
	{
		//double drad = Radian;
		//float rad = Radian + pi_over_32;
		float two_pi = (float)(2 * Math.PI);
		while (Radian < 0)
			Radian += two_pi;
		while (Radian >= two_pi)
			Radian -= two_pi;
		//Radian = rad - pi_over_32;
		int retval = Math.round(Radian / pi_over_16);
		if (retval == 32)
			retval = 0;
		return retval;
	}
	private float ImageCenterX()
	{
		return leg_graphics_list[StateNumber()].getWidth() / 2.0f;
	}
	private float ImageCenterY()
	{
		return leg_graphics_list[StateNumber()].getHeight() / 2.0f;
	}
	@Override
	public int GetWidth() {
		return leg_graphics_list[StateNumber()].getWidth();
	}
	@Override
	public int GetHeight() {
		return leg_graphics_list[StateNumber()].getHeight();
	}
	@Override
	public Point GetCenter() {
		return new Point (Math.round(ImageCenterX() - arm_diameter * FloatMath.sin(Radian) / 2), Math.round(ImageCenterY() + arm_diameter * FloatMath.cos(Radian) / 2));
	}
	@Override
	public Rect GetHitbox() {
		int i = StateNumber();
		if (hitbox_precache_avail[i])
			return hitbox_precache[i];
		int t = (int)arm_thickness;
		int w, h;
		switch (i)
		{
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
			h = leg_graphics_list[i].getHeight();
			hitbox_precache[i] = new Rect(0, h - t, t, h);
			hitbox_precache_avail[i] = true;
			return hitbox_precache[i];
		case 8:
		case 9:
		case 10:
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
			hitbox_precache[i] = new Rect(0, 0, t, t);
			hitbox_precache_avail[i] = true;
			return hitbox_precache[i];
		case 16:
		case 17:
		case 18:
		case 19:
		case 20:
		case 21:
		case 22:
		case 23:
			w = leg_graphics_list[i].getWidth();
			hitbox_precache[i] = new Rect(w - t, 0, w, t);
			hitbox_precache_avail[i] = true;
			return hitbox_precache[i];
		default:
			w = leg_graphics_list[i].getWidth();
			h = leg_graphics_list[i].getHeight();
			hitbox_precache[i] = new Rect(w - t, h - t, w, h);
			hitbox_precache_avail[i] = true;
			return hitbox_precache[i];
		}
	}
	@Override
	public Rect GetAttackbox() {
		int i = StateNumber();
		return new Rect(0, 0, leg_graphics_list[i].getWidth(), leg_graphics_list[i].getHeight());
	}

	@Override
	public void SetWidth(int _w) {
		throw new IllegalStateException ();
	}
	@Override
	public void SetHeight(int _h) {
		throw new IllegalStateException();
	}
	@Override
	public void SetCenter(Point _c) {
		throw new IllegalStateException();
	}

	@Override
	public void SetHitbox(Rect _r) {
		throw new IllegalStateException();
	}
	@Override
	public void SetAttackbox(Rect _r) {
		throw new IllegalStateException();
	}

	@Override
	public float GetX() {
		if (move_at_entity)
			return my_mother.GetAttachPoint().x + offset.x;
		else
			return offset.x;
	}
	@Override
	public float GetY() {
		if (move_at_entity)
			return my_mother.GetAttachPoint().y + offset.y;
		else
			return offset.y;
	}
	
	public void SetX(float _x)
	{
		if (move_at_entity)
			throw new IllegalStateException();
		else
			offset.x = _x;
	}
	public void SetY(float _y)
	{
		if (move_at_entity)
			throw new IllegalStateException();
		else
			offset.y = _y;
	}

	@Override
	public PointF GetPosition() {
		return new PointF(GetX(), GetY());
	}

	@Override
	public boolean IsMarkedForDeletion() {
		return deletion_flag;
	}

	public void SetDegree(float d)
	{
		Radian = (float)(d * Math.PI / 180);
	}
	public float GetDegree()
	{
		return (float)(Radian * 180 / Math.PI);
	}
	
	public PointF GetAttachPoint()
	{
		return new PointF(GetX() + arm_diameter * FloatMath.sin(Radian), GetY() - arm_diameter * FloatMath.cos(Radian));
	}
	
	public void onDraw(Canvas c)
	{
		Point center = this.GetCenter();
		int i = StateNumber();
		c.drawBitmap(leg_graphics_list[i], GetX() - center.x, GetY() - center.y, null);
	}
}
