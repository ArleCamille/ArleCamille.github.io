#!/usr/bin/env python

# We intended to code it with Python 3,
# but since pylibpcap is being really problematic in Py3 for now,
# we would instead use Python 2 for the meantime.

# Future directives
from __future__ import print_function

# Core libraries
import sys
import datetime
import time
import struct
import threading
import subprocess
import socket
import fcntl

# External libraries
import pcap
from arp import send_arp

ETHER_HEADER_SIZE = 14
ARP_HEADER_SIZE = 28

ARPHRD_ETHER = 1
ARPHRD_IEEE802 = 6
ETHERTYPE_ARP = 0x0806
ETHERTYPE_IP = 0x0800
ETHERTYPE_TRAIL = 0x1000
ARPOP_REQUEST = 1
ARPOP_REPLY = 2

CS_IDLE = 0
CS_WAITING = 1
CS_CONFLICT = 2
TIMEOUT_ARP_WAITING = 30.0
TIMEOUT_ARP_CONFLICT = 1.0

class Object (object):
    pass

def mac_to_readable (mac):
    return ':'.join (('%02x' % i) for i in struct.unpack ('!6B', mac))

def ip_to_readable (ip):
    return '.'.join (('%d' % i) for i in struct.unpack ('!4B', ip))

# almost verbatim from ARPWatch
def sanity_check (packet, logtime):
    if packet.ether_type != ETHERTYPE_ARP:
        print ("[%s] Packet from %s is not ARP! (Ether type: 0x%04x)\n" %
               (logtime, mac_to_readable (packet.ether_shost), packet.ether_type),
               file=sys.stderr)
        return False

    # ARPWatch says: SysV R4 seems to use IEEE802 instead.
    if packet.ar_hrd != ARPHRD_ETHER and packet.ar_hrd != ARPHRD_IEEE802:
        print ("[%s] ARP packet from %s has bad hardware format 0x%04x\n" %
               (logtime, mac_to_readable (packet.ether_shost), packet.ar_hrd),
               file=sys.stderr)
        return False
    # ARPWatch says: hds X terminals sometimes send trailer arp replies
    if packet.ar_pro != ETHERTYPE_IP and packet.ar_pro != ETHERTYPE_TRAIL:
        print ("[%s] ARP packet from %s has bad protocol 0x%04x\n" %
               (logtime, mac_to_readable (packet.ether_shost), packet.ar_pro),
               file=sys.stderr)
        return False
    if packet.ar_hln != 6 or packet.ar_pln != 4:
        print ("[%s] ARP packet from %s has bad address spec (HW=%d, Net=%d)\n" %
               (logtime, packet.ar_hln, packet.ar_pln),
               file=sys.stderr)
        return False
    if packet.ar_op != ARPOP_REQUEST and packet.ar_op != ARPOP_REPLY:
        print ("[%s] ARP packet from %s has bad opcode 0x%04x\n" %
               (logtime, mac_to_readable (packet.ether_shost), packet.ar_op),
               file=sys.stderr)
        return False

    return True

def parse_arp (p):
    # http://stackoverflow.com/a/2827664/2043960
    packet = Object ()
    # Ethernet header
    packet.ether_dhost = p[0:6]
    packet.ether_shost = p[6:12]
    packet.ether_type = struct.unpack ('!H', p[12:14])[0]

    # ARP content
    packet.ar_hrd = struct.unpack ('!H', p[14:16])[0]
    packet.ar_pro = struct.unpack ('!H', p[16:18])[0]
    packet.ar_hln = struct.unpack ('!B', p[18:19])[0]
    packet.ar_pln = struct.unpack ('!B', p[19:20])[0]
    packet.ar_op = struct.unpack ('!H', p[20:22])[0]
    packet.ar_sha = p[22:28]
    packet.ar_sip = p[28:32]
    packet.ar_dha = p[32:38]
    packet.ar_dip = p[38:42]

    return packet

canonical_mac = {}
potential_mac = {}
potential_garp_mac = {}
clients = {}

def log (logtime, message):
    if logtime == None:
        logtime = time.strftime ('%Y-%m-%d %H:%M:%s')
    print ("[%s] %s" % (logtime, message), file=sys.stderr)

def add_or_create (d, k, v):
    if k not in d or d[k] == None:
        d[k] = [v]
    elif v not in d[k]:
        d[k].append (v)

dev = None
safe_responses = []

def arpt_add_mac_rule (ip, new_mac):
    log (None, "Allowing %s claiming as %s." %
         (ip_to_readable (ip), mac_to_readable (new_mac)))
    #arptables -I INPUT 1 --opcode 2 -s (ip) --source-mac (new_mac) -i (dev) -j ACCEPT
    subprocess.call (['arptables', '-I', 'INPUT', '1', '--opcode', '2', '-s',
                      ip_to_readable (ip), '--source-mac', mac_to_readable (new_mac),
                      '-i', dev, '-j', 'ACCEPT'])
    subprocess.call (['arptables', '-I', 'FORWARD', '1', '--opcode', '2', '-s',
                      ip_to_readable (ip), '--source-mac', mac_to_readable (new_mac),
                      '-i', dev, '-j', 'ACCEPT'])

def arpt_change_mac_rule (ip, new_mac, old_mac):
    log (None, "Denying %s claiming as %s." %
         (ip_to_readable (ip), mac_to_readable (old_mac)))
    subprocess.call (['arptables', '-D', 'INPUT', '--opcode', '2', '-s',
                      ip_to_readable (ip), '--source-mac', mac_to_readable (old_mac),
                      '-i', dev, '-j', 'ACCEPT'])
    subprocess.call (['arptables', '-D', 'FORWARD', '--opcode', '2', '-s',
                      ip_to_readable (ip), '--source-mac', mac_to_readable (old_mac),
                      '-i', dev, '-j', 'ACCEPT'])
    arpt_add_mac_rule (ip, new_mac)

def arp_watch_trigger (plen, p, timestamp):
    global canonical_mac
    global potential_mac
    global potential_garp_mac
    global clients
    global safe_responses
    logtime = datetime.datetime.fromtimestamp (timestamp).strftime('%Y-%m-%d %H:%M:%S')
    if plen < ETHER_HEADER_SIZE + ARP_HEADER_SIZE:
        print ("[%s] Packet shorter than expected ARP packet size" % logtime,
               file=sys.stderr)
        return
    packet = parse_arp(p)
    if not sanity_check (packet, logtime):
        return # Error message is printed via sanity_check itself

    if (packet.ar_op == ARPOP_REPLY and
        (packet.ether_shost, packet.ether_dhost, packet.ar_sha, packet.ar_sip,
         packet.ar_dha, packet.ar_dip) in safe_responses):
        log (logtime, "Got an expected reply sent by me:")
        log (logtime, "(%s->%s) Tell %s (%s) that %s=%s." %
             (packet.ether_shost, packet.ether_dhost, packet.ar_sha,
              packet.ar_sip, packet.ar_dha, packet.ar_dip))
        safe_responses.remove ((packet.ether_shost, packet.ether_dhost,
                                packet.ar_sha, packet.ar_sip,
                                packet.ar_dha, packet.ar_dip))
    elif packet.ar_sip == packet.ar_dip:
        # Gratuitous ARP!
        print ("[%s] GARP %s from %s (%s) -> %s" %
               (logtime, ('request' if packet.ar_op == ARPOP_REQUEST else 'response'),
                mac_to_readable (packet.ar_sha),
                ip_to_readable (packet.ar_sip),
                mac_to_readable (packet.ar_dha)),
               file=sys.stderr)
        if packet.ar_sip == my_ip:
            if packet.ar_sha != my_mac:
                log (logtime, "Wait, it's ME (%s), YOU IDIOT! Sent response GARP" %
                     mac_to_readable (my_mac))
                # Send GARP in MY name.
                # Since it is a request, we don't add it to safe responses.
                #safe_responses.append ((my_mac, arp.bcast_mac, my_mac, my_ip, arp.bcast_mac, my_ip))
                send_arp (dev, my_mac, None, 'REQUEST', my_mac, my_ip, None, my_ip)
            else:
                log (logtime, "My GARP, probably good to ignore it.")
        elif packet.ar_sip in canonical_mac and canonical_mac [packet.ar_sip] != None:
            # We got a MAC address collision here!
            log (logtime, "%s is already taken by %s here!" %
                 (packet.ar_sip, canonical_mac [packet.ar_sip]))
            add_or_create (potential_mac, packet.ar_sip, packet.ar_sha)
            add_or_create (potential_garp_mac, packet.ar_sip, packet.ar_sha)
            send_arp (dev, None, None, 'REQUEST', None, None, None, packet.ar_sip)
            # Now that ARP datagram is sent, the global handler for ARP request
            # will be handling it afterwards.
        else:
            # Update canonical MAC
            log (logtime, "According to GARP from %s, now %s = %s." %
                 (mac_to_readable (packet.ar_sha),
                  mac_to_readable (packet.ar_sip), 
                  mac_to_readable (packet.ar_sha)))
            if packet.ar_sip in canonical_mac and canonical_mac [packet.ar_sip] != ar_sha:
                log (logtime, '(was %s)' % mac_to_readable (canonical_mac [packet.ar_sip]))
                arpt_change_mac_rule (packet.ar_sip, packet.ar_sha, canonical_mac [packet.ar_sip])
                if packet.ar_op == ARPOP_REPLY:
                    safe_responses.append ((packet.ether_shost, packet.ether_dhost,
                                            packet.ar_sha, packet.ar_sip,
                                            packet.ar_dha, packet.ar_dip))
                    send_arp (dev, packet.ether_shost, packet.ether_dhost,
                              'REPLY', packet.ar_sha, packet.ar_sip,
                              packet.ar_dha, packet.ar_dip)
            elif packet.ar_sip not in canonical_mac:
                arpt_add_mac_rule (packet.ar_sip, packet.ar_sha)
                if packet.ar_op == ARPOP_REPLY:
                    safe_responses.append ((packet.ether_shost, packet.ether_dhost,
                                            packet.ar_sha, packet.ar_sip,
                                            packet.ar_dha, packet.ar_dip))
                    send_arp (dev, packet.ether_shost, packet.ether_dhost,
                              'REPLY', packet.ar_sha, packet.ar_sip,
                              packet.ar_dha, packet.ar_dip)
            canonical_mac [packet.ar_sip] = packet.ar_sha
            for c in clients:
                # FIXME: Should we also transit from CS_CONFLICT to CS_IDLE?
                if packet.ar_sip in clients[c] and clients[c][packet.ar_sip].state != CS_IDLE:
                    clients[c][packet.ar_sip].timer.cancel()
                    clients[c][packet.ar_sip].state = CS_IDLE
            
    elif packet.ar_op == ARPOP_REQUEST:
        # We should only do state update, but for debug purpose, we log it.
        print ("[%s] (%s->%s) %s (%s): Who has %s?" %
               (logtime, mac_to_readable (packet.ether_shost),
                mac_to_readable (packet.ether_dhost),
                mac_to_readable (packet.ar_sha),
                ip_to_readable (packet.ar_sip),
                ip_to_readable (packet.ar_dip)))
        if packet.ar_sha not in clients:
            clients[packet.ar_sha] = {}
        if packet.ar_dip in clients[packet.ar_sha]:
            clients[packet.ar_sha][packet.ar_dip].timer.cancel()
        clients[packet.ar_sha][packet.ar_dip] = Object()
        clients[packet.ar_sha][packet.ar_dip].state = CS_WAITING
        clients[packet.ar_sha][packet.ar_dip].timer = \
            threading.Timer (TIMEOUT_ARP_WAITING, graceful_timeout,
                             [packet.ar_sha, packet.ar_dip])
        clients[packet.ar_sha][packet.ar_dip].timer.start()
    else: # ARPOP_RESPONSE
        if (packet.ether_shost, packet.ether_dhost,
            packet.ar_sha, packet.ar_sip,
            packet.ar_dha, packet.ar_dip) in safe_responses:
            # That response was expected, because I sent it for forwarding.
            safe_responses.remove ((packet.ether_shost, packet.ether_dhost,
                                    packet.ar_sha, packet.ar_sip,
                                    packet.ar_dha, packet.ar_dip))
            return
        # Was the client waiting for the response?
        log (logtime, "(%s->%s) %s: I am %s. Tell it to %s (%s)." %
             (mac_to_readable (packet.ether_shost),
              mac_to_readable (packet.ether_dhost),
              mac_to_readable (packet.ar_sha),
              ip_to_readable (packet.ar_sip),
              mac_to_readable (packet.ar_dha),
              ip_to_readable (packet.ar_dip)))
        if (packet.ar_sip == my_ip and packet.ar_sha != my_mac) or\
           packet.ar_dha not in clients or\
           packet.ar_sip not in clients[packet.ar_dha] or\
           clients[packet.ar_dha][packet.ar_sip].state == CS_IDLE:
            log (logtime, "POSSIBLE ARP SPOOFING!")
            if packet.ar_sip == my_ip:
                log (logtime, "Attacker %s is trying to masquerade as me, who is %s (%s)!" %
                     (mac_to_readable (packet.ar_sha), ip_to_readable (my_ip),
                      mac_to_readable (my_mac)))
                # Ping GARP! NOW!
                send_mac (dev, my_mac, None, 'REQUEST', my_mac, my_ip, None, my_ip)
            log (logtime, "Unexpected ARP response from %s (%s) to %s (%s)" %
                 (mac_to_readable (packet.ar_sha),
                  ip_to_readable (packet.ar_sip),
                  mac_to_readable (packet.ar_dha),
                  ip_to_readable (packet.ar_dip)))
            return
        if clients[packet.ar_dha][packet.ar_sip].state == CS_WAITING:
            clients[packet.ar_dha][packet.ar_sip].timer.cancel()
            clients[packet.ar_dha][packet.ar_sip].state = CS_CONFLICT
            clients[packet.ar_dha][packet.ar_sip].timer =\
                threading.Timer (TIMEOUT_ARP_CONFLICT, resolve_conflict,
                                 [packet.ar_dha, packet.ar_sip, packet.ar_dip])
            clients[packet.ar_dha][packet.ar_sip].timer.start()
        if packet.ar_sip not in potential_mac:
            potential_mac [packet.ar_sip] = []
        if packet.ar_sha not in potential_mac [packet.ar_sip]:
            potential_mac [packet.ar_sip].append (packet.ar_sha)

def graceful_timeout (ar_sha, ar_dip):
    clients[ar_sha][ar_dip].state = CS_IDLE
    log (None, "%s tired out waiting for IP address of %s and gave up." %
         (mac_to_readable (ar_sha), ip_to_readable (ar_dip)))

def resolve_conflict (source_mac, dest_ip, source_ip):
    global clients
    logtime = time.strftime('%Y-%m-%d %H:%M:%S')
    log (logtime, "Resolving MAC conflict for %s." % ip_to_readable (dest_ip))
    log (logtime, "Candidates:")
    for x in potential_mac [dest_ip]:
        log (logtime, "- %s" % mac_to_readable (x))
    if dest_ip in canonical_mac and \
       canonical_mac [dest_ip] in potential_mac [dest_ip]:
        # canonical MAC address has priority
        log (logtime, "Canonical MAC %s in candidates. Accepting %s." %
             (mac_to_readable (canonical_mac [dest_ip]),
              mac_to_readable (canonical_mac [dest_ip])))
    elif len (potential_mac [dest_ip]) == 1:
        log (logtime, "Only one candidate; accepting %s." %
             mac_to_readable (potential_mac [dest_ip][0]))
        if dest_ip not in canonical_mac:
            cmac = potential_mac [dest_ip][0]
            arpt_add_mac_rule (dest_ip, cmac)
            safe_responses.append ((cmac, source_mac,
                                    cmac, dest_ip,
                                    source_mac, source_ip))
            send_arp (dev, cmac, source_mac,
                      'REPLY', cmac, dest_ip,
                      source_mac, source_ip)
        else:
            cmac = potential_mac [dest_ip][0]
            arpt_change_mac_rule (dest_ip, cmac, canonical_mac [packet.ar_sip])
            safe_responses.append ((cmac, source_mac,
                                    cmac, dest_ip,
                                    source_mac, source_ip))
            send_arp (dev, cmac, source_mac,
                      'REPLY', cmac, dest_ip,
                      source_mac, source_ip)

        canonical_mac [dest_ip] = potential_mac [dest_ip][0]
    # CAUTION: Uncertainty issues from here.
    elif len (potential_garp_mac [dest_ip]) == 1 and\
         potential_garp_mac [dest_ip][0] in potential_mac [dest_ip]:
        log (logtime, "We are unsure about this incident.")
        log (logtime, "However, we think that %s, the only one who sent GARP, would probably be legal." %
             mac_to_readable (potential_garp_mac [dest_ip][0]))
        if dest_ip not in canonical_mac:
            cmac = potential_garp_mac [dest_ip][0]
            arpt_add_mac_rule (dest_ip, cmac)
            safe_responses.append ((cmac, source_mac,
                                    cmac, dest_ip,
                                    source_mac, source_ip))
            send_arp (dev, cmac, source_mac,
                      'REPLY', cmac, dest_ip,
                      source_mac, source_ip)
        else:
            cmac = potential_garp_mac [dest_ip][0]
            arpt_change_mac_rule (dest_ip, cmac, canonical_mac [packet.ar_sip])
            safe_responses.append ((cmac, source_mac,
                                    cmac, dest_ip,
                                    source_mac, source_ip))
            send_arp (dev, cmac, source_mac,
                      'REPLY', cmac, dest_ip,
                      source_mac, source_ip)
        canonical_mac [dest_ip] = potential_garp_mac [dest_ip][0]
    else:
        log (logtime, "WARNING! Cannot resolve ARP conflict on %s!" % dest_ip)
        log (logtime, "Administrator intervention required!")
        log (logtime, "Possible candidates include:")
        for x in potential_mac [dest_ip]:
            log (logtime, "- %s", mac_to_readable (x))
        return
    potential_mac [dest_ip] = []
    potential_garp_mac [dest_ip] = []
    clients [source_mac][dest_ip].state = CS_IDLE

# Pseudocode
# on ARPWatchTrigger (value: ARPPacket):
#     if value is malformed:
#         Report this incident
#     elif value.SourceIP == value.DestIP:
#         # GARP
#         if value.SourceIP in CanonicalMAC:
#             # MAC address collision!
#             PotentialMAC [value.SourceIP] += value.SourceMAC
#             PotentialGARPMAC [value.SourceIP] += value.SourceMAC
#             SendARPQuestion (MyIP, value.SourceIP)
#             # Since ARP datagram is sent, the global handler for ARP request will handle it afterwards.
#         else:
#             # Update
#             CanonicalMAC [value.SourceIP] = value.SourceMAC
#             # Assume that the waiting clients have their requests solved.
#             for c in Clients:
#                 if c [value.SourceIP] == CS_WAITING:
# #                     # XXX: Also CS_CONFLICT?
#                     c [value.SourceIP] = CS_IDLE
#             AllowARPReplyFrom (value.SourceIP, value.SourceMAC)
#     elif IsARPRequest (value):
#         Clients [value.SourceMAC][value.DestIP] = CS_WAITING
#         Clients [value.SourceMAC].SetTimerEvent (T_ARP_REQUEST_AGE, void => Clients [value.SourceMAC][value.DestIP] = CS_IDLE)
#     else: # response
#         switch (Clients [value.DestMAC]):
#             case CS_IDLE:
#                 report this incident
#                 return
#             case CS_WAITING:
#                 Clients [value.DestMAC].SetTimerEvent (T_ARP_CONFLICT_AGE, ResolveConflict (Clients [value.DestMAC], value.SourceIP))
#                 # fallthrough
#             case CS_CONFLICT:
#                 PotentialMAC [value.SourceIP] += value.SourceMAC
#                 break
# 
# function ResolveConflict (c: Client, destIp: IPAddress):
#     if len (PotentialMAC [destIp]) == 1:
#         CanonicalMAC [destIp] = PotentialMAC [destIp].pop ()
#     elif CanonicalMAC [destIp] in PotentialMAC [destIp]:
#         # canonical MAC address has priority
#         PotentialMAC [destIp].clear ()
#     elif len (PotentialGARPMAC [destIp]) == 1 && PotentialGARPMAC [destIp].top () in PotentialMAC [destIp]:
#         # CAUTION: Uncertainty arises from here.
#         # Usually peers who sent GARP are trustworthy, because ARP spoofing tends to be covert.
#         # This includes the event of new device installation.
#         CanonicalMAC [destIp] = PotentialGARPMAC [destIp].pop ()
#     else:
#         # FIXME: Requires administrator intervention currently!
#         report this incident
#         panic
#         return or throw
#     PotentialMAC [destIp].clear ()
#     PotentialGARPMAC [destIp].clear ()
#     c = CS_IDLE
# 
# function AllowARPReplyFrom (ip: IPAddress, mac: MACAddress):
#     call nftables to revoke existing rules involving source IP=ip
#     call nftables to allow ARP datagrams from source MAC=mac and source IP=ip
#

def mac_from_readable (readable_mac):
    mac = struct.pack (
        '!6B', *[int (x, 16) for x in readable_mac.split (':')]
    )
    return mac

def ip_from_readable (readable_ip):
    ip = struct.pack (
        '!4B', *[int (x) for x in readable_ip.split ('.')]
    )
    return ip

def compose_initial_arp ():
    # FIXME: This method is VERY dependant on the system's program
    #        and might become unusable if the system spec changes!
    arp_result = subprocess.Popen (['arp', '-nH',  'ether', '-i', dev], stdout=subprocess.PIPE)
    line = arp_result.stdout.readline ()
    log (None, "Ignoring header line %s" % line)
    for line in arp_result.stdout:
        log (None, "Seeing line %s" % line)
        entries = line.split () # We expect 5: Address, hwtype, hwaddress, flags mask, iface
        if len (entries) != 5:
            log (None, "No, we can't parse this.")
            continue
        print (entries, file=sys.stderr)
        address = ip_from_readable (entries [0])
        hwaddress = mac_from_readable (entries [2])
        canonical_mac [address] = hwaddress
        log (None, "Got it, %s is now %s." % (ip_to_readable (address), mac_to_readable (hwaddress)))
        arpt_add_mac_rule (address, hwaddress)

def arptables_backup ():
    arpt = subprocess.check_output ('arptables-save', stderr=sys.stderr)
    log (None, "Dumping current ARP tables:")
    print (arpt, file=sys.stderr)
    return arpt

def arptables_initialize ():
    # Insert our ARP rules at the head.
    # Why not policy? Because we don't want to deal with other interfaces.
    # FIXME: React to return codes.
    # arptables -I 1 input (ens33) -j ACCEPT
    subprocess.call (['arptables', '-I', 'INPUT', '1', '-i', dev, '-j', 'ACCEPT'])
    subprocess.call (['arptables', '-I', 'OUTPUT', '1', '-i', dev, '-j', 'ACCEPT'])
    subprocess.call (['arptables', '-I', 'FORWARD', '1', '-i', dev, '-j', 'ACCEPT'])
    subprocess.call (['arptables', '-I', 'INPUT', '1', '--opcode', '2', '-i', dev, '-j', 'DROP'])
    subprocess.call (['arptables', '-I', 'FORWARD', '1', '--opcode', '2', '-i', dev, '-j', 'DROP'])

def arptables_restore (arpt):
    log (None, "Restoring ARPtables. Argument given")
    print (arpt, file=sys.stderr)
    arptables_restore = subprocess.Popen ('arptables-restore', stdin=subprocess.PIPE, stderr=sys.stderr)
    arptables_restore.communicate (arpt)
    arptables_restore.stdin.close ()
    arptables_restore.wait ()
    # FIXME: React to arptables error

my_ether = None
my_ip = None

def myaddress ():
    sock = socket.socket (socket.AF_PACKET, socket.SOCK_RAW, socket.SOCK_RAW)
    sock.bind ((dev, socket.SOCK_RAW))

    socket_mac = sock.getsockname ()[4]
    
    sock_udp = socket.socket (socket.AF_INET, socket.SOCK_DGRAM)
    socket_ip = fcntl.ioctl (sock_udp.fileno (), 0x8915, struct.pack ('256s', dev [:15])) [20:24]

    return (socket_mac, socket_ip)

def main ():
    def dumpusage ():
        print ('usage: {0} <interface> [--use-system-arp]'.format (sys.argv [0]))
        sys.exit (0)

    if len (sys.argv) < 2 or len (sys.argv) > 3:
        dumpusage ()

    global dev
    use_system_arp = False

    if sys.argv [1] == '--use-system-arp':
        use_system_arp = True
        if len (sys.argv) == 3 and sys.argv [2] != '--use-system-arp':
            dev = sys.argv [2]
        else:
            dumpusage ()
    else:
        if len (sys.argv) == 3 and sys.argv [2] != '--use-system-arp':
            dumpusage ()
        elif len (sys.argv) == 3:
            use_system_arp = True
        dev = sys.argv [1]

    arpt = arptables_backup ()
    arptables_initialize ()

    # Regardless of the option, register myself.
    log (None, "Registering myself.")
    my_ether, my_ip = myaddress()
    log (None, "My MAC address: %s" % mac_to_readable (my_ether))
    log (None, "My IP address: %s" % ip_to_readable (my_ip))
    canonical_mac [my_ip] = my_ether

    p = pcap.pcapObject()
    net, mask = pcap.lookupnet (dev)

    # TODO: Complete ARP from the system ARP table
    # FIXME: This assumption doesn't work on an already compromised network
    if use_system_arp:
        compose_initial_arp ()

    p.open_live (dev, 1600, 0, 100)
    p.setfilter ('arp', 0, 0) # TODO: arp or rarp? arp?


    try:
        while 1:
            p.dispatch (1, arp_watch_trigger)
    except KeyboardInterrupt:
        # Force resolve every running timer.
        for c in clients:
            for i in clients[c]:
                clients[c][i].timer.cancel()
        print (sys.exc_type)
        print ('Shutting down.')
        print ('%d packets received, %d packets dropped, %d packets dropped by interface' % p.stats ())

    arptables_restore (arpt)

if __name__ == '__main__':
    main ()
