import socket
import fcntl
from struct import pack

# send_arp modified and adopted from
# https://github.com/krig/send_arp.py/blob/master/send_arp.py
bcast_mac = pack('!6B', *(0xFF,)*6)
zero_mac = pack('!6B', *(0x00,)*6)
ARPOP_REQUEST = pack('!H', 0x0001)
ARPOP_REPLY = pack('!H', 0x0002)
# Ethernet protocol type (=ARP)
ETHERNET_PROTOCOL_TYPE_ARP = pack('!H', 0x0806)
# ARP logical protocol type (Ethernet/IP)
ARP_PROTOCOL_TYPE_ETHERNET_IP = pack('!HHBB', 0x0001, 0x0800, 0x0006, 0x0004)

arp_sock = {}
dev_ip = {}

def send_arp (device, ether_src_mac, ether_dst_mac, arptype,
              arp_src_mac, arp_src_ip, arp_dst_mac, arp_dst_ip):
# def send_arp(ip, device, sender_mac, broadcast, netmask, arptype,
#              request_target_mac=zero_mac):
    #if_ipaddr = socket.gethostbyname(socket.gethostname())
    global arp_sock
    global dev_ip
    if device not in arp_sock or arp_sock[device] == None:
        arp_sock[device] = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.SOCK_RAW)
        arp_sock[device].bind((device, socket.SOCK_RAW))

    socket_mac = arp_sock[device].getsockname()[4]

    arpop = None
    if arptype == 'REQUEST':
        arpop = ARPOP_REQUEST
    elif arptype == 'REPLY':
        arpop = ARPOP_REPLY
    else: # The caller used the numbers directly
        arpop = pack ('!H', arptype)

    # Auto-fill fields if applicable
    if ether_src_mac == None:
        ether_src_mac = socket_mac
    if ether_dst_mac == None:
        ether_dst_mac = bcast_mac
    if arp_src_mac == None:
        arp_src_mac = socket_mac
    if arp_src_ip == None:
        if device not in dev_ip or dev_ip [device] == None:
            s = socket.socket (socket.AF_INET, socket.SOCK_DGRAM)
            dev_ip [device] = fcntl.ioctl (s.fileno (), 0x8915, pack ('256s', device[:15])) [20:24]
        arp_src_ip = dev_ip [device]
    if arp_dst_mac == None:
        arp_dst_mac = zero_mac

    arpframe = [
        # ## ETHERNET
        # destination MAC addr
        ether_dst_mac,
        # source MAC addr
        ether_src_mac,
        ETHERNET_PROTOCOL_TYPE_ARP,

        # ## ARP
        ARP_PROTOCOL_TYPE_ETHERNET_IP,
        # operation type
        arpop,
        # sender MAC addr
        arp_src_mac,
        # sender IP addr
        arp_src_ip,
        # target hardware addr
        arp_dst_mac,
        # target IP addr
        arp_dst_ip
        ]

    # send the ARP
    arp_sock[device].send(''.join(arpframe))

